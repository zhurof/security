﻿function screen(){
	var width = $(window).width();
	if(width >= 1820){
		return 'full';
	}else if(width>=1280 && width < 1820){
		return 'laptop';
	}else if(width >= 1024 && width < 1280){
		return 'tablet';
	}else if(width >= 768 && width < 1024){
		return 'phone'
	}else{
		return 'smallphone'
	}
}
function changeTemplate(){
	if(screen() != 'phone' && screen() != 'smallphone'){
		$('.header__menu').css('display','')
	}
}
$(document).ready(changeTemplate);
$(window).resize(changeTemplate);

$(window).on('load scroll',function(){
	if($(this).scrollTop()){
		$('.header').addClass('fixed');
	}else{
		$('.header').removeClass('fixed');
		$('.scroll-btn').removeClass('anim');
	}
})
$('.menu-btn').click(function(){
	$('.header__menu').fadeToggle(400);
})
$('.header__menu-close').click(function(){
	$('.header__menu').fadeOut(400);
})
$('.top-block__slider').slick({
	prevArrow: '<span class="slick-arrow top-block__arrow prev"></span>',
	nextArrow: '<span class="slick-arrow top-block__arrow next"></span>',
	responsive: [
		{
			breakpoint: 1280,
			settings: {
				arrows: false
			}
		}
	]
})

function validateInput(){
	if(!this.validity.valid){
		$(this).addClass('invalid')
	}else{
		$(this).removeClass('invalid')
	}
}
//типа валидация
$('[type=submit]').click(function(){
	var form = this.form
	if(form){
		$(form.elements).each(validateInput);
	}
})
$('input,textarea').on('input change',validateInput);

//Ненужная кнопка скрола
$('.scroll-btn').click(function(){
	$(this).addClass('anim');
	$('html, body').animate({
      scrollTop: +$('.services').offset().top + +$('.services').outerHeight()
    }, 800);
})

/* $('.actions__slider').on('afterChange',function(event, slick, currentSlide){
	var color = $(slick.$slides[currentSlide]).css('background-color');
	$('.actions__shadow-title').css('color',color);
}) */
$('.actions__slider').slick({
	prevArrow: '<span class="slick-arrow white actions__arrow prev"></span>',
	nextArrow: '<span class="slick-arrow white actions__arrow next"></span>',
	dots: true,
	dotsClass: 'actions__dots',
	appendDots: '.actions__head .wrapper', 
	customPaging: function(slider,index){
		return $(slider.$slides[index]).data('caption');
	},
	responsive: [
		{
			breakpoint: 1280,
			settings: {
				arrows: false
			}
		}
	]
})

//Слайдер карточек
function locateSlide(){
	var index = $(this).index(),
			amount = +$(this).siblings().length + 1,
			top = 95/(amount-1)*index,
			left = 110/(amount-1)*index;
	$(this).css('transform','translate('+left+'px,'+top+'px)')
}
$('.card-slider').each(function(){
	var slideAmount = $(this).children('.card-slider__item').size();
	if(slideAmount){
		$(this).children('.card-slider__item').each(locateSlide)
	}
})
$('.card-slider__item').click(function(){
	if(!$(this).is(':last-child')){
		$(this).appendTo($(this).parent());
		$(this).parent().children().each(locateSlide);
	}else{
		$(this).prependTo($(this).parent());
		$(this).parent().children().each(locateSlide);
	}
})
//табы
/* $('.tabs').each(function(){
	var index = 0;
	if($(this).find('.tabs__head .active').length){
		index = $(this).find('.tabs__head .active').eq(0).index();
	}else{
		$(this).find('.tabs__head>a').eq(0).addClass('active')
	}
	$(this).find('.tabs__item').eq(index).show();
})
$('.tabs__head>a').click(function(e){
	e.preventDefault();
	if(!$(this).is('.active')){
		var index = $(this).index();
		$(this).addClass('active').siblings('.active').removeClass('active');
		$(this).parents('.tabs').trigger('tabChange').find('.tabs__item').hide().eq(index).show();
	}
}) */
//отзывы
$('.reviews__persons').slick({
	slidesToShow: 3,
	centerMode: true,
	focusOnSelect: true,
	centerPadding: 0,
	prevArrow: '<span class="slick-arrow reviews__arrow prev"></span>',
	nextArrow: '<span class="slick-arrow reviews__arrow next"></span>',
	asNavFor: $('.reviews__slider'),
	responsive: [
		{
			breakpoint: 768,
			settings: {
				arrows: false
			}
		}
	]
})
$('.reviews__slider').slick({
	arrows: false,
	asNavFor: $('.reviews__persons'),
	dots: true,
	dotsClass: 'slick-dots reviews__dots',
	customPaging: function(){return ''},
	responsive: [
		{
			breakpoint: 768,
			settings: {
				dots: false
			}
		}
	]
})
// PERSPECTIVE
var wrap = document.querySelector('.card')
var hover = new perspective.Hover(wrap)

//Плавная прокрутка ссылкам меню
$('.header__menu a[href^="#"]').click(function(e){
	e.preventDefault();
	var hash = $(this).attr('href');
	if($(hash).length){
		$('.header__menu').css('display','');
		$('html, body').animate({
          scrollTop: $(hash).offset().top - 56
        }, 400);				
        return false;
	}
})

//Эрзац табы
$('.tabs').slick({
	accessability: false,
	infinite: false,
	swipe: false,
	fade: true,
	arrows: false,
	dots: true,
	dotsClass: 'tabs__head',
	customPaging: function(slider,i){
		return $(slider.$slides[i]).data('caption')
	}
})
$('.price-block__tabs').on('beforeChange',function(event,slick,currentSlide,nextSlide){
	var index = $(slick.$slides[nextSlide]).data('image');
	if(!isFinite(index)){
		index = nextSlide
	}
	$(this).parents('.price-block').find('.composition img').removeClass('active').eq(index).addClass('active');
})
